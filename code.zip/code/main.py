"""
Entry point for submission in code/main.py.
Delegates to the top-level main.py module.
"""

import sys
from pathlib import Path

# Ensure root directory is on PYTHONPATH
ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from main import run_auditor

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Ghost Data Forensic AI Auditor (code entrypoint)")
    parser.add_argument("--sample", action="store_true", help="Run against sample dataset")
    parser.add_argument("--requests", type=str, default=None, help="Custom requests CSV path")
    args = parser.parse_args()

    custom_path = Path(args.requests) if args.requests else None
    run_auditor(use_sample=args.sample, custom_requests_path=custom_path)
