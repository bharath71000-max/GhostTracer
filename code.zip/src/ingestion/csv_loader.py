"""
CSV Data Ingestion and Validation module.
"""

import sys
from typing import Optional
import pandas as pd
from pathlib import Path

# Ensure repo root is on sys.path
REPO_ROOT = Path(__file__).resolve().parent.parent.parent
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from config import (
    DELETION_REQUESTS_PATH,
    SAMPLE_REQUESTS_PATH,
    SAMPLE_OUTPUT_PATH,
    USER_IDENTITIES_PATH,
    USER_AUDIT_LOG_PATH,
    DELETION_RULES_PATH,
    SYSTEM_ACTIVITY_PATH,
    EVIDENCE_FILES_PATH,
)

class DataLoader:
    def __init__(
        self,
        use_sample: bool = False,
        custom_requests_path: Optional[Path] = None
    ):
        self.use_sample = use_sample
        self.requests_path = (
            custom_requests_path
            if custom_requests_path
            else (SAMPLE_REQUESTS_PATH if use_sample else DELETION_REQUESTS_PATH)
        )
        self._requests_df: Optional[pd.DataFrame] = None
        self._identities_df: Optional[pd.DataFrame] = None
        self._audit_log_df: Optional[pd.DataFrame] = None
        self._rules_df: Optional[pd.DataFrame] = None
        self._activity_df: Optional[pd.DataFrame] = None
        self._evidence_manifest_df: Optional[pd.DataFrame] = None

    def load_requests(self) -> pd.DataFrame:
        if self._requests_df is None:
            self._requests_df = pd.read_csv(self.requests_path)
        return self._requests_df

    def load_identities(self) -> pd.DataFrame:
        if self._identities_df is None:
            self._identities_df = pd.read_csv(USER_IDENTITIES_PATH)
        return self._identities_df

    def load_audit_log(self) -> pd.DataFrame:
        if self._audit_log_df is None:
            self._audit_log_df = pd.read_csv(USER_AUDIT_LOG_PATH)
        return self._audit_log_df

    def load_rules(self) -> pd.DataFrame:
        if self._rules_df is None:
            self._rules_df = pd.read_csv(DELETION_RULES_PATH)
        return self._rules_df

    def load_activity(self) -> pd.DataFrame:
        if self._activity_df is None:
            self._activity_df = pd.read_csv(SYSTEM_ACTIVITY_PATH)
        return self._activity_df

    def load_evidence_manifest(self) -> pd.DataFrame:
        if self._evidence_manifest_df is None:
            self._evidence_manifest_df = pd.read_csv(EVIDENCE_FILES_PATH)
        return self._evidence_manifest_df
