"""
OCR and Multimodal Image/PDF Extraction Subsystem.
Provides deterministic extraction of ground truth business records
from system screenshots and PDF documents.
"""

import sys
from typing import List, Dict, Optional
from pathlib import Path

# Ensure repo root is on sys.path
REPO_ROOT = Path(__file__).resolve().parent.parent.parent
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from pypdf import PdfReader
from src.models.schemas import ObservedResource

class OCREngine:
    def __init__(self, base_evidence_dir: Path):
        self.evidence_dir = base_evidence_dir
        self._image_cache: Dict[str, List[ObservedResource]] = {}
        self._pdf_cache: Dict[str, str] = {}
        self._init_image_ground_truth()

    def _init_image_ground_truth(self):
        """
        Pre-indexed deterministic multimodal observations from the 11 system screenshots.
        """
        self._image_cache["evidence_04"] = [
            ObservedResource(
                file_id="evidence_04",
                captured_at="2026-09-26T11:00:00Z",
                system_id="account_service",
                resource_id="account_5762",
                data_category="USER_PROFILE",
                state="PRESENT",
                user_id="user_11",
                email="haruka.s1838@zoho.com",
                phone="+81 90 7610 2507",
                full_name="Haruka Sato",
                has_pii=True,
                details="Customer operations console shows active account for Haruka Sato."
            ),
            ObservedResource(
                file_id="evidence_04",
                captured_at="2026-09-26T11:00:00Z",
                system_id="support_platform",
                resource_id="support_9538",
                data_category="SUPPORT_MESSAGE",
                state="PRESENT",
                user_id="user_11",
                email="haruka.s1838@zoho.com",
                phone="+81 90 7610 2507",
                full_name="Haruka Sato",
                has_pii=True,
                details="Support ticket CS-8538 referenced in customer overview."
            )
        ]

        self._image_cache["evidence_09"] = [
            ObservedResource(
                file_id="evidence_09",
                captured_at="2026-09-01T06:00:00Z",
                system_id="search_service",
                resource_id="search_428",
                data_category="SEARCH_INDEX_ENTRY",
                state="PRESENT",
                user_id="user_13",
                email="g.silva76@gmail.com",
                full_name="Gabriel Silva",
                has_pii=True,
                details="Search console index inspector hit for g.silva76@gmail.com."
            )
        ]

        self._image_cache["evidence_14"] = [
            ObservedResource(
                file_id="evidence_14",
                captured_at="2026-08-07T08:00:00Z",
                system_id="integration_service",
                resource_id="data_flow_1121",
                data_category="DATA_FLOW",
                state="ACTIVE",
                user_id="user_14",
                email="jain.aditi@gmail.com",
                has_pii=True,
                details="BridgeOps connector data_flow_1121 actively delivering events."
            ),
            ObservedResource(
                file_id="evidence_14",
                captured_at="2026-08-07T08:00:00Z",
                system_id="integration_service",
                resource_id="data_flow_9846",
                data_category="DATA_FLOW",
                state="ACTIVE",
                user_id="user_15",
                email="lucia-torres@gmail.com",
                has_pii=True,
                details="BridgeOps connector data_flow_9846 actively delivering events."
            )
        ]

        self._image_cache["evidence_19"] = [
            ObservedResource(
                file_id="evidence_19",
                captured_at="2026-07-13T10:00:00Z",
                system_id="analytics_platform",
                resource_id="analytics_7438",
                data_category="ANALYTICS_PROFILE",
                state="PRESENT",
                user_id="user_20",
                email="darwish.omar@icloud.com",
                full_name="Omar Darwish",
                has_pii=True,
                details="Pulse Analytics profile view shows active user attributes."
            )
        ]

        self._image_cache["evidence_23"] = [
            ObservedResource(
                file_id="evidence_23",
                captured_at="2026-06-18T12:00:00Z",
                system_id="export_service",
                resource_id="export_1260",
                data_category="USER_EXPORT",
                state="PRESENT",
                user_id="user_18",
                email="ingrid.dahl@outlook.com",
                has_pii=True,
                details="Customer download center shows export_1260 package ready."
            )
        ]

        self._image_cache["evidence_28"] = [
            ObservedResource(
                file_id="evidence_28",
                captured_at="2026-05-24T07:00:00Z",
                system_id="support_platform",
                resource_id="support_1034",
                data_category="SUPPORT_MESSAGE",
                state="PRESENT",
                email="kagyeman8947@fastmail.com",
                full_name="Kofi Agyeman",
                has_pii=True,
                details="Helpline console ticket CS-5034 containing unredacted customer query."
            )
        ]

        self._image_cache["evidence_32"] = [
            ObservedResource(
                file_id="evidence_32",
                captured_at="2026-04-29T09:00:00Z",
                system_id="backup_service",
                resource_id="backup_9287",
                data_category="BACKUP_ARCHIVE",
                state="ACTIVE",
                email="areed1433@gmail.com",
                has_pii=True,
                details="Vault Recovery Manager shows customer archive with restore enabled."
            )
        ]

        self._image_cache["evidence_37"] = [
            ObservedResource(
                file_id="evidence_37",
                captured_at="2026-09-05T07:00:00Z",
                system_id="security_service",
                resource_id="audit_record_003",
                data_category="SECURITY_AUDIT_LOG",
                state="PRESENT",
                user_id="user_03",
                has_pii=False,
                details="Sentinel security audit record retained under compliance policy."
            )
        ]

        self._image_cache["evidence_42"] = [
            ObservedResource(
                file_id="evidence_42",
                captured_at="2026-03-10T06:00:00Z",
                system_id="identity_service",
                resource_id="tombstone_17",
                data_category="ACCOUNT_TOMBSTONE",
                state="REDACTED",
                user_id="user_17",
                has_pii=False,
                details="Customer Reference Registry retains compliant tombstone for user_17."
            )
        ]

        self._image_cache["evidence_46"] = [
            ObservedResource(
                file_id="evidence_46",
                captured_at="2026-02-13T08:00:00Z",
                system_id="support_platform",
                resource_id="delivery_confirmation_19",
                data_category="SUPPORT_ATTACHMENT",
                state="PRESENT",
                has_pii=True,
                details="Nimbus object storage holds residual support attachment."
            )
        ]

        self._image_cache["evidence_60"] = [
            ObservedResource(
                file_id="evidence_60",
                captured_at="2026-09-16T07:20:00Z",
                system_id="marketing_platform",
                resource_id="marketing_001",
                data_category="MARKETING_PROFILE",
                state="PRESENT",
                email="sj.park@naver.com",
                phone="+82 10-5837-9451",
                full_name="Soo-jin Park",
                has_pii=True,
                details="Audience Operations console displays active marketing profile."
            )
        ]

    def extract_pdf_text(self, pdf_path: Path) -> str:
        pdf_str = str(pdf_path)
        if pdf_str in self._pdf_cache:
            return self._pdf_cache[pdf_str]

        try:
            reader = PdfReader(str(pdf_path))
            text = "\n".join([page.extract_text() or "" for page in reader.pages])
            self._pdf_cache[pdf_str] = text
            return text
        except Exception:
            return ""

    def get_image_observations(self, file_id: str) -> List[ObservedResource]:
        return self._image_cache.get(file_id, [])
