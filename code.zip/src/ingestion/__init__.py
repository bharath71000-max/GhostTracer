import sys
from pathlib import Path
REPO_ROOT = Path(__file__).resolve().parent.parent.parent
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

try:
    from .csv_loader import DataLoader
    from .ocr_engine import OCREngine
    from .evidence_parser import EvidenceParser
except (ImportError, ValueError):
    from src.ingestion.csv_loader import DataLoader
    from src.ingestion.ocr_engine import OCREngine
    from src.ingestion.evidence_parser import EvidenceParser

__all__ = ["DataLoader", "OCREngine", "EvidenceParser"]
