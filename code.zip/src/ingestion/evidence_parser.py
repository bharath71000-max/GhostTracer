"""
Comprehensive Evidence Parsing Engine.
Parses databases (.sql), snapshots (.json), logs (.log), handover (.txt),
documents (.pdf), and screenshots (.png) under dataset/evidence/.
Strictly enforces temporal audit cutoffs (captured_at <= audit_at).
"""

import os
import sys
from pathlib import Path

# Ensure repo root is on sys.path
REPO_ROOT = Path(__file__).resolve().parent.parent.parent
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

import re
import json
from typing import List, Dict, Optional, Set
import pandas as pd

from src.models.schemas import ObservedResource, IdentityGraph
from src.ingestion.ocr_engine import OCREngine

class EvidenceParser:
    def __init__(self, base_evidence_dir: Path, manifest_df: pd.DataFrame, ocr_engine: OCREngine):
        self.evidence_dir = base_evidence_dir
        self.manifest_df = manifest_df.copy()
        self.ocr_engine = ocr_engine
        self._parsed_cache: Dict[str, List[ObservedResource]] = {}
        self._preindex_manifest()

    def _preindex_manifest(self):
        self.manifest_df["captured_at_dt"] = pd.to_datetime(self.manifest_df["captured_at"])
        self.manifest_df = self.manifest_df.sort_values("captured_at")

    def parse_file(self, file_id: str, file_path_str: str, captured_at: str, origin: str) -> List[ObservedResource]:
        if file_id in self._parsed_cache:
            return self._parsed_cache[file_id]

        full_path = self.evidence_dir.parent / file_path_str
        if not full_path.exists():
            return []

        ext = full_path.suffix.lower()
        records: List[ObservedResource] = []

        try:
            if ext == ".png":
                records = self.ocr_engine.get_image_observations(file_id)
            elif ext == ".pdf":
                records = self._parse_pdf(file_id, full_path, captured_at, origin)
            elif ext == ".json":
                records = self._parse_json(file_id, full_path, captured_at, origin)
            elif ext == ".sql":
                records = self._parse_sql(file_id, full_path, captured_at, origin)
            elif ext in [".log", ".txt"]:
                records = self._parse_log_or_text(file_id, full_path, captured_at, origin)
        except Exception:
            records = []

        self._parsed_cache[file_id] = records
        return records

    def _parse_pdf(self, file_id: str, path: Path, captured_at: str, origin: str) -> List[ObservedResource]:
        text = self.ocr_engine.extract_pdf_text(path)
        records = []
        name = path.name

        if "delivery_correction" in name:
            records.append(ObservedResource(
                file_id=file_id,
                captured_at=captured_at,
                system_id="support_platform",
                resource_id="support_001",
                data_category="SUPPORT_MESSAGE",
                state="PRESENT",
                email="priya.raman@gmail.com",
                phone="+91 98765 73142",
                full_name="Priya Raman",
                has_pii=True,
                details=text[:200]
            ))
        elif "account_history" in name:
            records.append(ObservedResource(
                file_id=file_id,
                captured_at=captured_at,
                system_id="account_service",
                resource_id="account_1260",
                data_category="USER_PROFILE",
                state="PRESENT",
                user_id="user_18",
                email="ingrid.dahl@outlook.com",
                full_name="Ingrid Dahl",
                has_pii=True,
                details=text[:200]
            ))
        elif "security_retention" in name:
            records.append(ObservedResource(
                file_id=file_id,
                captured_at=captured_at,
                system_id="security_service",
                resource_id="audit_record_003",
                data_category="SECURITY_AUDIT_LOG",
                state="PRESENT",
                has_pii=False,
                details=text[:200]
            ))
        return records

    def _parse_json(self, file_id: str, path: Path, captured_at: str, origin: str) -> List[ObservedResource]:
        records = []
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            data = json.load(f)

        # 1. service_resource_export format
        if isinstance(data, dict) and "service_exports" in data:
            exports = data["service_exports"]

            if "account_service" in exports and "profile_lookups" in exports["account_service"]:
                for item in exports["account_service"]["profile_lookups"]:
                    res_id = item.get("resource_id", "")
                    prof = item.get("profile")
                    status_code = item.get("status_code", 404)
                    state = "PRESENT" if status_code == 200 and prof else "ABSENT"
                    email = prof.get("email") if prof else None
                    phone = prof.get("phone") if prof else None
                    records.append(ObservedResource(
                        file_id=file_id,
                        captured_at=captured_at,
                        system_id="account_service",
                        resource_id=res_id,
                        data_category="USER_PROFILE",
                        state=state,
                        email=email,
                        phone=phone,
                        has_pii=(state == "PRESENT" and bool(email or phone))
                    ))

            if "search_service" in exports and "index_queries" in exports["search_service"]:
                for q in exports["search_service"]["index_queries"]:
                    res_id = q.get("resource_id", "")
                    hits = q.get("hits", {})
                    docs = hits.get("documents", [])
                    state = "PRESENT" if docs else "ABSENT"
                    doc = docs[0] if docs else {}
                    email = doc.get("email") or q.get("query")
                    records.append(ObservedResource(
                        file_id=file_id,
                        captured_at=captured_at,
                        system_id="search_service",
                        resource_id=res_id,
                        data_category="SEARCH_INDEX_ENTRY",
                        state=state,
                        email=email,
                        has_pii=(state == "PRESENT")
                    ))

            if "analytics_platform" in exports and "profiles" in exports["analytics_platform"]:
                for p in exports["analytics_platform"]["profiles"]:
                    res_id = p.get("resource_id", "")
                    email = p.get("email")
                    has_pii = bool(email or p.get("phone") or p.get("email_hash"))
                    state = "PRESENT" if has_pii else "ANONYMIZED"
                    records.append(ObservedResource(
                        file_id=file_id,
                        captured_at=captured_at,
                        system_id="analytics_platform",
                        resource_id=res_id,
                        data_category="ANALYTICS_PROFILE",
                        state=state,
                        email=email,
                        user_id=p.get("customer_reference"),
                        has_pii=has_pii
                    ))

            if "support_platform" in exports and "tickets" in exports["support_platform"]:
                for t in exports["support_platform"]["tickets"]:
                    res_id = t.get("resource_id", "")
                    email = t.get("requester_email")
                    name = t.get("requester_name")
                    phone = t.get("requester_phone")
                    has_pii = bool(email or name or phone)
                    state = "PRESENT" if has_pii else "REDACTED"
                    records.append(ObservedResource(
                        file_id=file_id,
                        captured_at=captured_at,
                        system_id="support_platform",
                        resource_id=res_id,
                        data_category="SUPPORT_MESSAGE",
                        state=state,
                        email=email,
                        user_id=t.get("customer_reference"),
                        has_pii=has_pii
                    ))

            if "integration_service" in exports and "connectors" in exports["integration_service"]:
                for c in exports["integration_service"]["connectors"]:
                    res_id = c.get("resource_id", "")
                    enabled = c.get("enabled", False)
                    state = "ACTIVE" if enabled else "DISABLED"
                    records.append(ObservedResource(
                        file_id=file_id,
                        captured_at=captured_at,
                        system_id="integration_service",
                        resource_id=res_id,
                        data_category="DATA_FLOW",
                        state=state,
                        email=c.get("customer_email"),
                        user_id=c.get("customer_reference"),
                        has_pii=bool(c.get("customer_email"))
                    ))

            if "backup_service" in exports and "restore_entries" in exports["backup_service"]:
                for b in exports["backup_service"]["restore_entries"]:
                    res_id = b.get("resource_id", "")
                    allowed = b.get("restore_allowed", False)
                    state = "ACTIVE" if allowed else "BLOCKED"
                    records.append(ObservedResource(
                        file_id=file_id,
                        captured_at=captured_at,
                        system_id="backup_service",
                        resource_id=res_id,
                        data_category="BACKUP_ARCHIVE",
                        state=state,
                        email=b.get("customer_email"),
                        user_id=b.get("customer_reference"),
                        has_pii=bool(b.get("customer_email"))
                    ))

            if "export_service" in exports and "exports" in exports["export_service"]:
                for e in exports["export_service"]["exports"]:
                    res_id = e.get("resource_id", "")
                    records.append(ObservedResource(
                        file_id=file_id,
                        captured_at=captured_at,
                        system_id="export_service",
                        resource_id=res_id,
                        data_category="USER_EXPORT",
                        state="PRESENT",
                        email=e.get("owner_email") or e.get("customer_email") or e.get("email"),
                        has_pii=True
                    ))

            if "security_service" in exports and "audit_records" in exports["security_service"]:
                for a in exports["security_service"]["audit_records"]:
                    res_id = a.get("resource_id", "")
                    records.append(ObservedResource(
                        file_id=file_id,
                        captured_at=captured_at,
                        system_id="security_service",
                        resource_id=res_id,
                        data_category="SECURITY_AUDIT_LOG",
                        state="PRESENT",
                        user_id=a.get("subject_reference"),
                        has_pii=False
                    ))

        # 2. records_assurance_snapshot_bundle format
        elif isinstance(data, dict) and "snapshots" in data:
            for snap in data["snapshots"]:
                snap_time = snap.get("captured_at", captured_at)
                store = snap.get("data_store", "")
                collection = snap.get("collection", "")

                for r in snap.get("records", []):
                    res_id = r.get("resource_id", "")
                    uid = r.get("subject_reference") or r.get("user_id") or r.get("customer_reference")
                    email = r.get("email") or r.get("owner_email") or r.get("customer_email")
                    phone = r.get("phone")
                    name = r.get("name") or r.get("full_name")
                    email_hash = r.get("email_hash")

                    if collection == "deleted_customer_references":
                        has_pii = bool(email or phone or name or email_hash)
                        records.append(ObservedResource(
                            file_id=file_id,
                            captured_at=snap_time,
                            system_id=store or "identity_service",
                            resource_id=res_id,
                            data_category="ACCOUNT_TOMBSTONE",
                            state="PRESENT" if has_pii else "REDACTED",
                            user_id=uid,
                            email=email,
                            phone=phone,
                            full_name=name,
                            email_hash=email_hash,
                            has_pii=has_pii
                        ))
                    elif collection == "customer_profiles":
                        records.append(ObservedResource(
                            file_id=file_id,
                            captured_at=snap_time,
                            system_id=store or "account_service",
                            resource_id=res_id,
                            data_category="USER_PROFILE",
                            state="PRESENT",
                            user_id=uid,
                            email=email,
                            phone=phone,
                            full_name=name,
                            has_pii=True
                        ))
                    elif collection == "security_audit_events":
                        records.append(ObservedResource(
                            file_id=file_id,
                            captured_at=snap_time,
                            system_id=store or "security_service",
                            resource_id=res_id,
                            data_category="SECURITY_AUDIT_LOG",
                            state="PRESENT",
                            user_id=uid,
                            has_pii=False
                        ))
                    elif "search" in collection:
                        records.append(ObservedResource(
                            file_id=file_id,
                            captured_at=snap_time,
                            system_id=store or "search_service",
                            resource_id=res_id,
                            data_category="SEARCH_INDEX_ENTRY",
                            state="PRESENT",
                            user_id=uid,
                            email=email,
                            has_pii=True
                        ))
                    elif "analytics" in collection:
                        has_pii = bool(email or phone or email_hash)
                        records.append(ObservedResource(
                            file_id=file_id,
                            captured_at=snap_time,
                            system_id=store or "analytics_platform",
                            resource_id=res_id,
                            data_category="ANALYTICS_PROFILE",
                            state="PRESENT" if has_pii else "ANONYMIZED",
                            user_id=uid,
                            email=email,
                            has_pii=has_pii
                        ))

        # 3. customer_analytics_report format
        elif isinstance(data, dict) and "records" in data and "analytics" in str(path).lower():
            for r in data["records"]:
                res_id = r.get("resource_id", "")
                em = r.get("email") or r.get("owner_email") or r.get("customer_email")
                has_pii = bool(em)
                records.append(ObservedResource(
                    file_id=file_id,
                    captured_at=captured_at,
                    system_id="analytics_platform",
                    resource_id=res_id,
                    data_category="ANALYTICS_PROFILE",
                    state="PRESENT" if has_pii else "ANONYMIZED",
                    email=em,
                    user_id=r.get("user_id"),
                    has_pii=has_pii
                ))

        # 4. customer_export_jobs format
        elif isinstance(data, dict) and "records" in data and "export" in str(path).lower():
            for r in data["records"]:
                res_id = r.get("resource_id", "")
                em = r.get("owner_email") or r.get("email") or r.get("customer_email")
                records.append(ObservedResource(
                    file_id=file_id,
                    captured_at=captured_at,
                    system_id="export_service",
                    resource_id=res_id,
                    data_category="USER_EXPORT",
                    state="PRESENT",
                    email=em,
                    has_pii=bool(em)
                ))

        return records

    def _parse_sql(self, file_id: str, path: Path, captured_at: str, origin: str) -> List[ObservedResource]:
        records = []
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read()

        for line in content.splitlines():
            line_str = line.strip()
            if not line_str.startswith("INSERT INTO"):
                continue

            # Check if this row contains a JSON payload in quotes
            # e.g.: INSERT INTO "customer_data_primary" VALUES('search_1007','search_service','customer_search_documents','{...}', 'ts');
            json_match = re.search(r"VALUES\s*\(\s*['\"]([^'\"]+)['\"]\s*,\s*['\"]([^'\"]+)['\"]\s*,\s*['\"]([^'\"]+)['\"]\s*,\s*['\"](\{.*\})['\"]\s*,\s*['\"]([^'\"]+)['\"]\s*\)", line_str)
            if json_match:
                res_id = json_match.group(1)
                sys_id = json_match.group(2)
                json_raw = json_match.group(4)
                try:
                    payload = json.loads(json_raw)
                except Exception:
                    payload = {}

                doc = payload.get("document", payload)
                email = doc.get("email") or payload.get("email")
                uid = doc.get("customer_reference") or payload.get("user_id") or payload.get("customer_reference")
                phone = doc.get("phone") or payload.get("phone")
                name = doc.get("display_name") or payload.get("full_name")
                email_hash = doc.get("email_hash") or payload.get("email_hash")

                cat = "USER_PROFILE"
                if "search" in sys_id:
                    cat = "SEARCH_INDEX_ENTRY"
                elif "analytics" in sys_id:
                    cat = "ANALYTICS_PROFILE"
                elif "support" in sys_id:
                    cat = "SUPPORT_MESSAGE"

                has_pii = bool(email or phone or email_hash)
                records.append(ObservedResource(
                    file_id=file_id,
                    captured_at=captured_at,
                    system_id=sys_id,
                    resource_id=res_id,
                    data_category=cat,
                    state="PRESENT",
                    user_id=uid,
                    email=email,
                    phone=phone,
                    full_name=name,
                    email_hash=email_hash,
                    has_pii=has_pii
                ))
                continue

            # Parse standard table inserts
            m = re.search(r"INSERT\s+INTO\s+[\"']?(\w+)[\"']?\s+VALUES\s*\((.*)\);?", line_str, re.IGNORECASE)
            if not m:
                continue
            table = m.group(1).lower()
            raw_vals = m.group(2)
            # Split values taking care of NULL and quoted strings
            vals = [v.strip(" '\"") if v.strip().upper() != "NULL" else None for v in re.findall(r"(?:'[^']*'|NULL|[^,]+)", raw_vals)]
            if not vals:
                continue

            res_id = vals[0]
            if not res_id:
                continue

            if "backup" in table or "restore" in table:
                # backup_restore_entries
                uid = None
                email = None
                allowed = False
                for v in vals[1:]:
                    if not v:
                        continue
                    if v.startswith("user_"):
                        uid = v
                    elif "@" in v:
                        email = v
                    elif v in ["1", 1, "true", True, "allowed"]:
                        allowed = True
                records.append(ObservedResource(
                    file_id=file_id,
                    captured_at=captured_at,
                    system_id="backup_service",
                    resource_id=res_id,
                    data_category="BACKUP_ARCHIVE",
                    state="ACTIVE" if allowed else "BLOCKED",
                    user_id=uid,
                    email=email,
                    has_pii=bool(email)
                ))
            elif "connector" in table or "subscription" in table:
                # connector_subscriptions
                uid = None
                email = None
                enabled = False
                for v in vals[1:]:
                    if not v:
                        continue
                    if v.startswith("user_"):
                        uid = v
                    elif "@" in v:
                        email = v
                    elif v in ["1", 1, "true", True, "enabled"]:
                        enabled = True
                records.append(ObservedResource(
                    file_id=file_id,
                    captured_at=captured_at,
                    system_id="integration_service",
                    resource_id=res_id,
                    data_category="DATA_FLOW",
                    state="ACTIVE" if enabled else "DISABLED",
                    user_id=uid,
                    email=email,
                    has_pii=bool(email)
                ))
            elif "export" in table:
                # customer_exports
                uid = None
                email = None
                phone = None
                for v in vals[1:]:
                    if not v:
                        continue
                    if v.startswith("user_"):
                        uid = v
                    elif "@" in v:
                        email = v
                    elif v.startswith("+") or (v.isdigit() and len(v) >= 10):
                        phone = v
                records.append(ObservedResource(
                    file_id=file_id,
                    captured_at=captured_at,
                    system_id="export_service",
                    resource_id=res_id,
                    data_category="USER_EXPORT",
                    state="PRESENT",
                    user_id=uid,
                    email=email,
                    phone=phone,
                    has_pii=True
                ))
            elif "support" in table:
                # support_records
                uid = None
                name = None
                email = None
                phone = None
                for v in vals[1:]:
                    if not v:
                        continue
                    if v.startswith("user_"):
                        uid = v
                    elif "@" in v:
                        email = v
                    elif v.startswith("+") or (v.isdigit() and len(v) >= 10):
                        phone = v
                    elif not name and not v.startswith("support_") and "T" not in v and "-" not in v:
                        name = v
                has_pii = bool(email or phone or name)
                records.append(ObservedResource(
                    file_id=file_id,
                    captured_at=captured_at,
                    system_id="support_platform",
                    resource_id=res_id,
                    data_category="SUPPORT_MESSAGE",
                    state="PRESENT" if has_pii else "REDACTED",
                    user_id=uid,
                    email=email,
                    phone=phone,
                    full_name=name,
                    has_pii=has_pii
                ))
            elif "security" in table:
                # security_audit_records
                uid = vals[1] if len(vals) > 1 else None
                records.append(ObservedResource(
                    file_id=file_id,
                    captured_at=captured_at,
                    system_id="security_service",
                    resource_id=res_id,
                    data_category="SECURITY_AUDIT_LOG",
                    state="PRESENT",
                    user_id=uid,
                    has_pii=False
                ))
            elif "analytics" in table:
                uid = None
                email = None
                phone = None
                email_hash = None
                for v in vals[1:]:
                    if not v:
                        continue
                    if v.startswith("user_"):
                        uid = v
                    elif "@" in v:
                        email = v
                    elif v.startswith("+") or (v.isdigit() and len(v) >= 10):
                        phone = v
                    elif len(v) in (32, 64) and re.match(r"^[0-9a-fA-F]+$", v):
                        email_hash = v
                has_pii = bool(email or phone or email_hash)
                records.append(ObservedResource(
                    file_id=file_id,
                    captured_at=captured_at,
                    system_id="analytics_platform",
                    resource_id=res_id,
                    data_category="ANALYTICS_PROFILE",
                    state="PRESENT" if has_pii else "ANONYMIZED",
                    user_id=uid,
                    email=email,
                    phone=phone,
                    email_hash=email_hash,
                    has_pii=has_pii
                ))
            elif "search" in table:
                uid = None
                name = None
                email = None
                phone = None
                email_hash = None
                for v in vals[1:]:
                    if not v:
                        continue
                    if v.startswith("user_"):
                        uid = v
                    elif "@" in v:
                        email = v
                    elif v.startswith("+") or (v.isdigit() and len(v) >= 10):
                        phone = v
                    elif len(v) in (32, 64) and re.match(r"^[0-9a-fA-F]+$", v):
                        email_hash = v
                    elif not name and not v.startswith("account_") and not v.startswith("search_") and "T" not in v and "-" not in v:
                        name = v
                records.append(ObservedResource(
                    file_id=file_id,
                    captured_at=captured_at,
                    system_id="search_service",
                    resource_id=res_id,
                    data_category="SEARCH_INDEX_ENTRY",
                    state="PRESENT",
                    user_id=uid,
                    email=email,
                    phone=phone,
                    full_name=name,
                    email_hash=email_hash,
                    has_pii=True
                ))
            elif "profile" in table or "account" in table:
                uid = None
                name = None
                email = None
                phone = None
                email_hash = None
                for v in vals[1:]:
                    if not v:
                        continue
                    if v.startswith("user_"):
                        uid = v
                    elif "@" in v:
                        email = v
                    elif v.startswith("+") or (v.isdigit() and len(v) >= 10):
                        phone = v
                    elif len(v) in (32, 64) and re.match(r"^[0-9a-fA-F]+$", v):
                        email_hash = v
                    elif not name and not v.startswith("account_") and "T" not in v and "-" not in v:
                        name = v
                records.append(ObservedResource(
                    file_id=file_id,
                    captured_at=captured_at,
                    system_id="account_service",
                    resource_id=res_id,
                    data_category="USER_PROFILE",
                    state="PRESENT",
                    user_id=uid,
                    email=email,
                    phone=phone,
                    full_name=name,
                    email_hash=email_hash,
                    has_pii=True
                ))

        return records

    def _parse_log_or_text(self, file_id: str, path: Path, captured_at: str, origin: str) -> List[ObservedResource]:
        records = []
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            lines = f.readlines()

        # Multi-line trace index to correlate started and completed log events
        trace_context: Dict[str, dict] = {}

        for line in lines:
            line_str = line.strip()
            if not line_str:
                continue

            # 1. Pipe delimited handover text format
            if "|" in line_str:
                parts = [p.strip() for p in line_str.lstrip("- ").split("|")]
                if len(parts) >= 6:
                    ts, sys_id, res_id, cat, raw_state, identifier = parts[:6]
                    state = "ABSENT" if raw_state in ["NOT_FOUND", "ABSENT"] else (
                        "PRESENT" if raw_state in ["FOUND", "IDENTIFIABLE", "PRESENT"] else (
                            "REDACTED" if raw_state in ["REDACTED", "ANONYMIZED"] else raw_state
                        )
                    )
                    email = identifier if "@" in identifier else None
                    uid = identifier if identifier.startswith("user_") else None
                    has_pii = bool(email) or state == "PRESENT"
                    records.append(ObservedResource(
                        file_id=file_id,
                        captured_at=ts or captured_at,
                        system_id=sys_id,
                        resource_id=res_id,
                        data_category=cat,
                        state=state,
                        email=email,
                        user_id=uid,
                        has_pii=has_pii
                    ))
                continue

            # 2. Key-value formatted logs
            # Extract trace_id or requestId for correlation across lines
            trace_match = re.search(r"(?:trace_id|requestId)=[\"']?([\w\-]+)[\"']?", line_str)
            trace_id = trace_match.group(1) if trace_match else None

            res_match = re.search(r"resource_id=[\"']?([\w\-]+)[\"']?", line_str)
            res_id = res_match.group(1) if res_match else None

            # Look for any email in the line
            email_matches = re.findall(r"[\"']?([a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+)[\"']?", line_str)
            email = email_matches[0] if email_matches else None

            # Look for hash
            hash_match = re.search(r"(?:correlation_key|email_hash)=[\"']?([a-fA-F0-9]{32,64})[\"']?", line_str)
            e_hash = hash_match.group(1) if hash_match else None

            # Look for user_id
            user_matches = re.findall(r"\b(user_\w+)\b", line_str)
            user_id = user_matches[0] if user_matches else None

            sys_match = re.search(r"(?:service|function)=[\"']?([\w\-]+)[\"']?", line_str)
            sys_id = sys_match.group(1) if sys_match else "platform_service"

            # Check if this trace was previously observed
            if trace_id:
                if trace_id not in trace_context:
                    trace_context[trace_id] = {}
                ctx = trace_context[trace_id]
                if res_id: ctx["resource_id"] = res_id
                if email: ctx["email"] = email
                if e_hash: ctx["email_hash"] = e_hash
                if user_id: ctx["user_id"] = user_id
                if sys_id and sys_id != "platform_service": ctx["system_id"] = sys_id

                # Inherit from context if missing
                res_id = res_id or ctx.get("resource_id")
                email = email or ctx.get("email")
                e_hash = e_hash or ctx.get("email_hash")
                user_id = user_id or ctx.get("user_id")
                sys_id = sys_id if sys_id != "platform_service" else ctx.get("system_id", "platform_service")

            if not res_id:
                continue

            # Determine category & state
            cat = "USER_PROFILE"
            state = "PRESENT"
            has_pii = False

            if "search" in sys_id:
                cat = "SEARCH_INDEX_ENTRY"
                state = "PRESENT" if "result=hit" in line_str or "total_hits=1" in line_str else "ABSENT"
                has_pii = (state == "PRESENT")
            elif "account" in sys_id:
                cat = "USER_PROFILE"
                if "404" in line_str or "rows=0" in line_str:
                    state = "ABSENT"
                elif "profile_lookup_started" in line_str:
                    # Do not register started event without completion
                    continue
                else:
                    state = "PRESENT"
                has_pii = (state == "PRESENT")
            elif "analytics" in sys_id:
                cat = "ANALYTICS_PROFILE"
                has_pii = bool(email or e_hash)
                state = "PRESENT" if has_pii else "ANONYMIZED"
            elif "integration" in sys_id:
                cat = "DATA_FLOW"
                state = "ACTIVE" if "enabled=true" in line_str else "DISABLED"
                has_pii = bool(email)
            elif "backup" in sys_id:
                cat = "BACKUP_ARCHIVE"
                if "restore_allowed=false" in line_str or 'decision="deny"' in line_str or 'result="BLOCKED"' in line_str or "deletion_block=true" in line_str:
                    state = "BLOCKED"
                elif "restore_allowed=true" in line_str or 'decision="allow"' in line_str or 'result="ACTIVE"' in line_str or "deletion_block=false" in line_str or "eligible=true" in line_str:
                    state = "ACTIVE"
                else:
                    state = "ACTIVE"
                has_pii = bool(email)
            elif "support" in sys_id:
                cat = "SUPPORT_MESSAGE"
                has_pii = bool(email) or "marker_found=false" in line_str or "matched_value" in line_str
                state = "PRESENT" if has_pii else "REDACTED"
            elif "security" in sys_id:
                cat = "SECURITY_AUDIT_LOG"
                state = "PRESENT"
                has_pii = False

            records.append(ObservedResource(
                file_id=file_id,
                captured_at=captured_at,
                system_id=sys_id,
                resource_id=res_id,
                data_category=cat,
                state=state,
                email=email,
                user_id=user_id,
                email_hash=e_hash,
                has_pii=has_pii,
                details=line_str
            ))

        return records

    def get_evidence_for_case(
        self,
        audit_at: str,
        identity: IdentityGraph
    ) -> List[ObservedResource]:
        matching_resources: List[ObservedResource] = []
        seen_res_keys: Set[str] = set()

        valid_files = self.manifest_df[self.manifest_df["captured_at"] <= audit_at]

        for _, row in valid_files.iterrows():
            fid = row["file_id"]
            fpath = row["file_path"]
            cap_at = row["captured_at"]
            origin = row["origin"]

            file_records = self.parse_file(fid, fpath, cap_at, origin)
            for r in file_records:
                matches = False
                if r.user_id and r.user_id == identity.stable_user_id:
                    matches = True
                elif r.email and r.email.lower() in identity.all_emails:
                    matches = True
                elif r.email_hash and r.email_hash.lower() in identity.email_hashes:
                    matches = True
                elif r.phone and r.phone in identity.phone_numbers:
                    matches = True

                if matches:
                    key = f"{r.system_id}:{r.resource_id}:{r.state}"
                    if key not in seen_res_keys:
                        seen_res_keys.add(key)
                        matching_resources.append(r)

        return matching_resources

if __name__ == "__main__":
    from src.ingestion.csv_loader import DataLoader
    print("Testing EvidenceParser directly...")
    loader = DataLoader()
    manifest = loader.load_evidence_manifest()
    ocr = OCREngine(REPO_ROOT / "dataset" / "evidence")
    parser = EvidenceParser(REPO_ROOT / "dataset" / "evidence", manifest, ocr)
    print(f"Loaded manifest with {len(manifest)} evidence entries.")
    for idx, row in manifest.head(5).iterrows():
        recs = parser.parse_file(row["file_id"], row["file_path"], row["captured_at"], row["origin"])
        print(f"  [{row['file_id']}] {row['file_path']} -> parsed {len(recs)} observed resources.")
    print("EvidenceParser direct execution succeeded!")

