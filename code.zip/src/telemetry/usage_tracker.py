"""
Telemetry and Token Usage Tracking Subsystem.
Tracks API calls, token counts, model latency, and cost estimates.
"""

from typing import Dict, List, Optional
from pydantic import BaseModel, Field

class ModelUsageMetric(BaseModel):
    model_name: str
    provider: str
    calls: int = 0
    input_tokens: int = 0
    output_tokens: int = 0
    cost_per_million_input: float = 0.15   # USD (e.g. Gemini / Flash tier)
    cost_per_million_output: float = 0.60  # USD

    @property
    def total_tokens(self) -> int:
        return self.input_tokens + self.output_tokens

    @property
    def estimated_cost_usd(self) -> float:
        input_cost = (self.input_tokens / 1_000_000.0) * self.cost_per_million_input
        output_cost = (self.output_tokens / 1_000_000.0) * self.cost_per_million_output
        return round(input_cost + output_cost, 6)

class TelemetryTracker:
    def __init__(self):
        self.metrics: Dict[str, ModelUsageMetric] = {
            "gemini-3.8-flash": ModelUsageMetric(
                model_name="gemini-3.8-flash",
                provider="Google Cloud Vertex AI",
                calls=0,
                input_tokens=0,
                output_tokens=0,
                cost_per_million_input=0.15,
                cost_per_million_output=0.60
            ),
            "deterministic-core": ModelUsageMetric(
                model_name="deterministic-core-py312",
                provider="Local Python 3.12 Engine",
                calls=0,
                input_tokens=0,
                output_tokens=0,
                cost_per_million_input=0.0,
                cost_per_million_output=0.0
            )
        }

    def record_call(self, model_key: str, input_tokens: int, output_tokens: int):
        if model_key not in self.metrics:
            self.metrics[model_key] = ModelUsageMetric(
                model_name=model_key,
                provider="External / AI Model",
                calls=0,
                input_tokens=0,
                output_tokens=0
            )
        m = self.metrics[model_key]
        m.calls += 1
        m.input_tokens += input_tokens
        m.output_tokens += output_tokens

    def get_summary(self, total_cases: int = 518) -> dict:
        total_calls = sum(m.calls for m in self.metrics.values())
        total_inp = sum(m.input_tokens for m in self.metrics.values())
        total_out = sum(m.output_tokens for m in self.metrics.values())
        total_tok = total_inp + total_out
        total_cost = sum(m.estimated_cost_usd for m in self.metrics.values())

        avg_tok_per_case = round(total_tok / max(1, total_cases), 2)
        avg_cost_per_case = round(total_cost / max(1, total_cases), 6)

        models_dict = {}
        for k, m in self.metrics.items():
            d = m.model_dump()
            d["total_tokens"] = m.total_tokens
            d["estimated_cost_usd"] = m.estimated_cost_usd
            models_dict[k] = d

        return {
            "total_cases": total_cases,
            "total_calls": total_calls,
            "total_input_tokens": total_inp,
            "total_output_tokens": total_out,
            "total_tokens": total_tok,
            "total_cost_usd": total_cost,
            "avg_tokens_per_case": avg_tok_per_case,
            "avg_cost_per_case": avg_cost_per_case,
            "models": models_dict
        }
