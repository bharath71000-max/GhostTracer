import sys
from pathlib import Path
REPO_ROOT = Path(__file__).resolve().parent.parent.parent
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

try:
    from .usage_tracker import TelemetryTracker
    from .report_generator import ReportGenerator
except (ImportError, ValueError):
    from src.telemetry.usage_tracker import TelemetryTracker
    from src.telemetry.report_generator import ReportGenerator

__all__ = ["TelemetryTracker", "ReportGenerator"]
