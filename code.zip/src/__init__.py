"""
Ghost Data Forensic AI Auditor package.
"""
