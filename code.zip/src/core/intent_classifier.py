"""
Multilingual Intent Classification Engine.
Determines whether a user request authorizes data deletion or represents a
non-deletion request (SAR, access, correction, export, marketing opt-out).
"""

from typing import Optional, Set
import re
from pydantic import BaseModel, Field

class IntentClassificationResult(BaseModel):
    is_deletion_request: bool = Field(description="True if request demands data/account deletion.")
    confidence_score: float = Field(ge=0.0, le=1.0)
    detected_language: str = Field(default="en")
    request_category: str = Field(description="ERASURE, ACCESS, EXPORT, CORRECTION, OPT_OUT, OTHER")
    reasoning_summary: str = Field(description="Brief justification of the classification.")

class IntentClassifier:
    NON_DELETION_PATTERNS = [
        r"leave\s+the\s+account\s+active",
        r"leave\s+my\s+profile",
        r"not\s+asking\s+for\s+deletion",
        r"keep\s+the\s+account",
        r"do\s+not\s+close",
        r"without\s+removing",
        r"marketing\s+lists?\s+only",
        r"promotional\s+emails?",
        r"information\s+request",
        r"what\s+personal\s+information\s+you\s+hold",
        r"continue\s+using\s+the\s+service",
        r"don['’]?t\s+delete\s+or\s+change",
        r"portable\s+format",
        r"download\s+my\s+account\s+information",
        r"copy\s+of\s+last\s+year['’]?s\s+invoices",
        r"send\s+me\s+a\s+copy\s+of\s+the\s+information",
        r"resetting\s+the\s+login",
        r"misspelled\s+on\s+the\s+account",
        r"replace\s+it\s+with\s+the\s+new\s+one",
        r"change\s+the\s+email\s+address\s+used\s+for\s+this\s+account",
    ]

    DELETION_KEYWORDS = [
        "delete", "deleting", "deletion", "erased", "erase", "erasure",
        "remove", "removing", "close", "closed", "suppression", "supprimer",
        "exclusão", "excluir", "eliminación", "eliminar", "löschen", "löschung",
        "effacer", "cancellazione", "cancella", "verwijderen", "削除", "삭제",
        "gone", "cannot identify", "can not identify"
    ]

    def __init__(self, non_deletion_accounts: Optional[Set[str]] = None):
        """
        Optional non_deletion_accounts set can be provided from system_activity CLASSIFY_REQUEST.
        """
        self.non_deletion_accounts = non_deletion_accounts or set()

    def classify(
        self,
        request_text: str,
        account_id: Optional[str] = None
    ) -> IntentClassificationResult:
        if not request_text:
            return IntentClassificationResult(
                is_deletion_request=False,
                confidence_score=1.0,
                request_category="OTHER",
                reasoning_summary="Empty request text received."
            )

        text_lower = request_text.lower().strip()

        # 1. System activity explicit non-deletion authorization check
        if account_id and account_id in self.non_deletion_accounts:
            return IntentClassificationResult(
                is_deletion_request=False,
                confidence_score=1.0,
                request_category="NON_DELETION",
                reasoning_summary=f"Privacy intake recorded explicit non-deletion classification for {account_id}."
            )

        # 2. Check explicit non-deletion patterns
        for pattern in self.NON_DELETION_PATTERNS:
            if re.search(pattern, text_lower):
                category = "OPT_OUT" if "marketing" in pattern or "promo" in pattern else (
                    "EXPORT" if "download" in pattern or "portable" in pattern or "copy" in pattern else (
                        "CORRECTION" if "change" in pattern or "misspell" in pattern or "replace" in pattern else "ACCESS"
                    )
                )
                return IntentClassificationResult(
                    is_deletion_request=False,
                    confidence_score=0.99,
                    request_category=category,
                    reasoning_summary=f"Matched non-deletion pattern: '{pattern}'."
                )

        # 3. Check positive deletion intent
        has_deletion_intent = any(kw in text_lower for kw in self.DELETION_KEYWORDS)

        if has_deletion_intent:
            return IntentClassificationResult(
                is_deletion_request=True,
                confidence_score=1.0,
                request_category="ERASURE",
                reasoning_summary="Request explicitly authorizes account/personal data erasure."
            )

        # Default fallback
        return IntentClassificationResult(
            is_deletion_request=False,
            confidence_score=0.85,
            request_category="OTHER",
            reasoning_summary="No definitive erasure intent detected in submission text."
        )
