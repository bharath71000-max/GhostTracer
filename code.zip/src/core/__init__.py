import sys
from pathlib import Path
REPO_ROOT = Path(__file__).resolve().parent.parent.parent
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

try:
    from .identity_graph import IdentityResolver
    from .intent_classifier import IntentClassifier, IntentClassificationResult
    from .activity_checker import ActivityChecker
    from .policy_evaluator import PolicyEvaluator
except (ImportError, ValueError):
    from src.core.identity_graph import IdentityResolver
    from src.core.intent_classifier import IntentClassifier, IntentClassificationResult
    from src.core.activity_checker import ActivityChecker
    from src.core.policy_evaluator import PolicyEvaluator

__all__ = [
    "IdentityResolver",
    "IntentClassifier",
    "IntentClassificationResult",
    "ActivityChecker",
    "PolicyEvaluator",
]
