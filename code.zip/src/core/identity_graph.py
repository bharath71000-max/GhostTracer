"""
Identity Graph Resolution Engine.
Constructs a transitive closure graph of all historical and current identity anchors.
"""

import sys
from pathlib import Path

# Ensure repo root is on sys.path
REPO_ROOT = Path(__file__).resolve().parent.parent.parent
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

import re
from typing import Set, List, Dict, Optional
import pandas as pd
from src.models.schemas import IdentityGraph

class IdentityResolver:
    def __init__(self, identities_df: pd.DataFrame, audit_log_df: pd.DataFrame):
        self.identities_df = identities_df.copy()
        self.audit_log_df = audit_log_df.copy()

        # Pre-clean string columns
        self.identities_df["email_clean"] = self.identities_df["email"].astype(str).str.strip().str.lower()
        self.identities_df["user_id_clean"] = self.identities_df["user_id"].astype(str).str.strip()

        self.audit_log_df["old_val_clean"] = self.audit_log_df["old_value"].astype(str).str.strip().str.lower()
        self.audit_log_df["new_val_clean"] = self.audit_log_df["new_value"].astype(str).str.strip().str.lower()
        self.audit_log_df["user_id_clean"] = self.audit_log_df["user_id"].astype(str).str.strip()

        # Build quick lookups
        self._email_to_user_id: Dict[str, str] = {}
        for _, row in self.identities_df.iterrows():
            self._email_to_user_id[row["email_clean"]] = row["user_id_clean"]

        for _, row in self.audit_log_df.iterrows():
            field = str(row.get("field_name", "")).lower()
            if "email" in field:
                uid = row["user_id_clean"]
                for val in [row["old_val_clean"], row["new_val_clean"]]:
                    if val and "@" in val and val != "nan":
                        if val not in self._email_to_user_id:
                            self._email_to_user_id[val] = uid

    def _normalize_phone(self, phone: str) -> Set[str]:
        if not phone or pd.isna(phone):
            return set()
        p_str = str(phone).strip()
        raw_digits = re.sub(r"\D", "", p_str)
        variants = {p_str, raw_digits}
        if len(raw_digits) == 10:
            variants.add(f"+1{raw_digits}")
            variants.add(f"{raw_digits[:3]}-{raw_digits[3:6]}-{raw_digits[6:]}")
        elif len(raw_digits) > 7:
            variants.add(raw_digits[-10:])
        return {v for v in variants if len(v) >= 7}

    def resolve_user_id(self, email: str) -> Optional[str]:
        cleaned = email.strip().lower()
        return self._email_to_user_id.get(cleaned)

    def build_graph(self, email: str) -> IdentityGraph:
        cleaned_email = email.strip().lower()
        user_id = self.resolve_user_id(cleaned_email)

        if not user_id:
            # Fallback for unregistered / unknown user
            return IdentityGraph(
                stable_user_id="UNKNOWN",
                primary_email=cleaned_email,
                all_emails=[cleaned_email],
                phone_numbers=[],
                email_hashes=[],
                full_names=[]
            )

        emails: Set[str] = {cleaned_email}
        phones: Set[str] = set()
        hashes: Set[str] = set()
        names: Set[str] = set()

        # 1. Inspect primary identity record
        u_rows = self.identities_df[self.identities_df["user_id_clean"] == user_id]
        if not u_rows.empty:
            row = u_rows.iloc[0]
            if pd.notna(row.get("email")):
                emails.add(str(row["email"]).strip().lower())
            if pd.notna(row.get("phone")):
                phones.update(self._normalize_phone(row["phone"]))
            if pd.notna(row.get("email_hash")):
                hashes.add(str(row["email_hash"]).strip().lower())
            if pd.notna(row.get("name")):
                names.add(str(row["name"]).strip())

        # 2. Inspect historical changes from audit log
        logs = self.audit_log_df[self.audit_log_df["user_id_clean"] == user_id]
        for _, log in logs.iterrows():
            field = str(log.get("field_name", "")).lower()
            old_val = str(log.get("old_value", "")).strip() if pd.notna(log.get("old_value")) else ""
            new_val = str(log.get("new_value", "")).strip() if pd.notna(log.get("new_value")) else ""

            for val in [old_val, new_val]:
                if not val or val.lower() == "nan":
                    continue
                if "email" in field and "@" in val:
                    emails.add(val.lower())
                elif "phone" in field:
                    phones.update(self._normalize_phone(val))
                elif "hash" in field:
                    hashes.add(val.lower())
                elif "name" in field:
                    names.add(val)

        return IdentityGraph(
            stable_user_id=user_id,
            primary_email=cleaned_email,
            all_emails=sorted(list(emails)),
            phone_numbers=sorted(list(phones)),
            email_hashes=sorted(list(hashes)),
            full_names=sorted(list(names))
        )
