"""
Activity and Restore Risk Checker Engine.
Inspects system_activity.csv to identify active data recreation risks,
synchronization jobs, and backup restore paths.
"""

import sys
from pathlib import Path

# Ensure repo root is on sys.path
REPO_ROOT = Path(__file__).resolve().parent.parent.parent
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from typing import List, Dict, Optional, Tuple, Set
import pandas as pd
from src.models.schemas import IdentityGraph, ObservedResource

class ActivityChecker:
    def __init__(self, activity_df: pd.DataFrame):
        self.activity_df = activity_df.copy()
        self.activity_df["dt"] = pd.to_datetime(self.activity_df["event_time"])
        self.activity_df = self.activity_df.sort_values("dt")

    def get_non_deletion_classified_accounts(self) -> Set[str]:
        """
        Returns set of resource_ids classified by privacy intake as non-deletion.
        """
        clf = self.activity_df[self.activity_df["event_type"] == "CLASSIFY_REQUEST"]
        return set(clf["resource_id"].dropna().unique())

    def find_account_resource_near_report(
        self,
        reported_at: str,
        user_id: Optional[str] = None
    ) -> Optional[str]:
        """
        Finds the primary account_service resource associated with this request
        by inspecting DELETE_RECORD events around reported_at.
        """
        if not reported_at or pd.isna(reported_at):
            return None

        t = pd.to_datetime(reported_at)
        # Search window within +/- 15 minutes of reported_at
        near = self.activity_df[
            (self.activity_df["dt"] >= t - pd.Timedelta(minutes=15)) &
            (self.activity_df["dt"] <= t + pd.Timedelta(minutes=15)) &
            (self.activity_df["target_system"] == "account_service") &
            (self.activity_df["event_type"] == "DELETE_RECORD")
        ]
        if not near.empty:
            return near.iloc[0]["resource_id"]

        return None

    def check_risks(
        self,
        audit_at: str,
        identity: IdentityGraph
    ) -> List[ObservedResource]:
        """
        Checks for active data flows or restore risks affecting the user before audit_at.
        """
        risks: List[ObservedResource] = []
        t_cutoff = pd.to_datetime(audit_at)
        valid_acts = self.activity_df[self.activity_df["dt"] <= t_cutoff]

        # Scan for active data flows or syncs
        # e.g., CHECK_DATA_FLOW or SYNC_RECORD with ACTIVE / RUNNING
        for _, row in valid_acts.iterrows():
            etype = str(row.get("event_type", ""))
            details = str(row.get("details", "")).lower()
            res_id = str(row.get("resource_id", ""))
            act_id = str(row.get("activity_id", ""))
            ts = str(row.get("event_time", ""))

            # Check if details or resource points to user
            matches = False
            for email in identity.all_emails:
                if email in details:
                    matches = True
                    break
            if identity.stable_user_id and identity.stable_user_id.lower() in details:
                matches = True

            if matches:
                if etype in ["SYNC_RECORD", "CHECK_DATA_FLOW", "DATA_FLOW"] and row.get("reported_result") != "FAILED":
                    risks.append(ObservedResource(
                        file_id=act_id,
                        captured_at=ts,
                        system_id="integration_service",
                        resource_id=res_id if res_id and res_id != "nan" else "data_flow_active",
                        data_category="DATA_FLOW",
                        state="ACTIVE",
                        has_pii=True,
                        details=details
                    ))
                elif etype in ["RESTORE_BACKUP", "CHECK_RESTORE_ACCESS"] and row.get("reported_result") != "FAILED":
                    risks.append(ObservedResource(
                        file_id=act_id,
                        captured_at=ts,
                        system_id="backup_service",
                        resource_id=res_id if res_id and res_id != "nan" else "backup_active",
                        data_category="BACKUP_ARCHIVE",
                        state="ACTIVE",
                        has_pii=True,
                        details=details
                    ))

        return risks
