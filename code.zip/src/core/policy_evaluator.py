"""
Policy Evaluation Engine.
Evaluates pre-cutoff evidence observations against deletion_rules.csv
to detect policy violations, exposed PII, active flows, and restore risks.
"""

import sys
from pathlib import Path

# Ensure repo root is on sys.path
REPO_ROOT = Path(__file__).resolve().parent.parent.parent
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from typing import List, Dict, Optional, Tuple
import pandas as pd
from src.models.schemas import ObservedResource, DeletionStep, IdentityGraph
from src.models.enums import AuditPhase

class PolicyEvaluator:
    def __init__(self, rules_df: pd.DataFrame):
        self.rules_df = rules_df

    def evaluate_resource(
        self,
        res: ObservedResource
    ) -> Tuple[Optional[dict], Optional[dict], dict]:
        """
        Evaluates a single observed resource against retention rules.
        Returns (finding_dict_or_None, remediation_dict_or_None, verification_dict).
        """
        cat = res.data_category.upper()
        st = res.state.upper()
        sys_id = res.system_id
        res_id = res.resource_id
        ev_id = res.file_id

        # 1. DELETE categories
        if cat in ["USER_PROFILE", "SECONDARY_IDENTIFIER", "SEARCH_INDEX_ENTRY", "CACHE_ENTRY", "USER_EXPORT", "SUPPORT_ATTACHMENT", "MARKETING_PROFILE"]:
            if st == "PRESENT":
                finding = {
                    "phase": "FINDING",
                    "operation": "REPORT_REMAINING_RECORD",
                    "system_id": sys_id,
                    "resource_id": res_id,
                    "state": "PRESENT",
                    "evidence_id": ev_id
                }
                remediation = {
                    "phase": "REMEDIATION",
                    "operation": "DELETE_RECORD",
                    "system_id": sys_id,
                    "resource_id": res_id,
                    "state": "ABSENT",
                    "evidence_id": ""
                }
                verification = {
                    "phase": "VERIFICATION",
                    "operation": "VERIFY_RECORD_ABSENT",
                    "system_id": sys_id,
                    "resource_id": res_id,
                    "state": "ABSENT",
                    "evidence_id": ""
                }
                return finding, remediation, verification
            else:
                # Compliant absent record
                return None, None, {
                    "phase": "VERIFICATION",
                    "operation": "VERIFY_RECORD_ABSENT",
                    "system_id": sys_id,
                    "resource_id": res_id,
                    "state": "ABSENT",
                    "evidence_id": ev_id
                }

        # 2. REDACT categories (Support message, Email delivery log, Tombstone)
        elif cat in ["SUPPORT_MESSAGE", "EMAIL_DELIVERY_LOG", "ACCOUNT_TOMBSTONE"]:
            if st == "PRESENT" or res.has_pii:
                finding = {
                    "phase": "FINDING",
                    "operation": "REPORT_EXPOSED_PII",
                    "system_id": sys_id,
                    "resource_id": res_id,
                    "state": "PRESENT",
                    "evidence_id": ev_id
                }
                remediation = {
                    "phase": "REMEDIATION",
                    "operation": "REDACT_RECORD",
                    "system_id": sys_id,
                    "resource_id": res_id,
                    "state": "REDACTED",
                    "evidence_id": ""
                }
                verification = {
                    "phase": "VERIFICATION",
                    "operation": "VERIFY_RECORD_REDACTED",
                    "system_id": sys_id,
                    "resource_id": res_id,
                    "state": "REDACTED",
                    "evidence_id": ""
                }
                return finding, remediation, verification
            else:
                return None, None, {
                    "phase": "VERIFICATION",
                    "operation": "VERIFY_RECORD_REDACTED",
                    "system_id": sys_id,
                    "resource_id": res_id,
                    "state": "REDACTED",
                    "evidence_id": ev_id
                }

        # 3. ANONYMIZE categories (Analytics, Telemetry)
        elif cat in ["ANALYTICS_PROFILE", "PRODUCT_TELEMETRY"]:
            if st == "PRESENT" or res.has_pii:
                finding = {
                    "phase": "FINDING",
                    "operation": "REPORT_EXPOSED_PII",
                    "system_id": sys_id,
                    "resource_id": res_id,
                    "state": "PRESENT",
                    "evidence_id": ev_id
                }
                remediation = {
                    "phase": "REMEDIATION",
                    "operation": "ANONYMIZE_RECORD",
                    "system_id": sys_id,
                    "resource_id": res_id,
                    "state": "ANONYMIZED",
                    "evidence_id": ""
                }
                verification = {
                    "phase": "VERIFICATION",
                    "operation": "VERIFY_RECORD_ANONYMIZED",
                    "system_id": sys_id,
                    "resource_id": res_id,
                    "state": "ANONYMIZED",
                    "evidence_id": ""
                }
                return finding, remediation, verification
            else:
                return None, None, {
                    "phase": "VERIFICATION",
                    "operation": "VERIFY_RECORD_ANONYMIZED",
                    "system_id": sys_id,
                    "resource_id": res_id,
                    "state": "ANONYMIZED",
                    "evidence_id": ev_id
                }

        # 4. DATA_FLOW categories (Integration / Synchronization)
        elif cat == "DATA_FLOW":
            if st == "ACTIVE":
                finding = {
                    "phase": "FINDING",
                    "operation": "REPORT_ACTIVE_DATA_FLOW",
                    "system_id": sys_id,
                    "resource_id": res_id,
                    "state": "ACTIVE",
                    "evidence_id": ev_id
                }
                remediation = {
                    "phase": "REMEDIATION",
                    "operation": "DISABLE_DATA_FLOW",
                    "system_id": sys_id,
                    "resource_id": res_id,
                    "state": "DISABLED",
                    "evidence_id": ""
                }
                verification = {
                    "phase": "VERIFICATION",
                    "operation": "VERIFY_DATA_FLOW_DISABLED",
                    "system_id": sys_id,
                    "resource_id": res_id,
                    "state": "DISABLED",
                    "evidence_id": ""
                }
                return finding, remediation, verification
            else:
                return None, None, {
                    "phase": "VERIFICATION",
                    "operation": "VERIFY_DATA_FLOW_DISABLED",
                    "system_id": sys_id,
                    "resource_id": res_id,
                    "state": "DISABLED",
                    "evidence_id": ev_id
                }

        # 5. BACKUP_ARCHIVE categories (Restore risk)
        elif cat == "BACKUP_ARCHIVE":
            if st == "ACTIVE":
                finding = {
                    "phase": "FINDING",
                    "operation": "REPORT_RESTORE_RISK",
                    "system_id": sys_id,
                    "resource_id": res_id,
                    "state": "ACTIVE",
                    "evidence_id": ev_id
                }
                remediation = {
                    "phase": "REMEDIATION",
                    "operation": "BLOCK_RESTORE",
                    "system_id": sys_id,
                    "resource_id": res_id,
                    "state": "BLOCKED",
                    "evidence_id": ""
                }
                verification = {
                    "phase": "VERIFICATION",
                    "operation": "VERIFY_RESTORE_BLOCKED",
                    "system_id": sys_id,
                    "resource_id": res_id,
                    "state": "BLOCKED",
                    "evidence_id": ""
                }
                return finding, remediation, verification
            else:
                return None, None, {
                    "phase": "VERIFICATION",
                    "operation": "VERIFY_RESTORE_BLOCKED",
                    "system_id": sys_id,
                    "resource_id": res_id,
                    "state": "BLOCKED",
                    "evidence_id": ev_id
                }

        # 6. RETAIN categories (Security audit log, Legal hold)
        elif cat in ["SECURITY_AUDIT_LOG", "LEGAL_HOLD_RECORD"]:
            return None, None, {
                "phase": "VERIFICATION",
                "operation": "VERIFY_RECORD_PRESENT",
                "system_id": sys_id,
                "resource_id": res_id,
                "state": "PRESENT",
                "evidence_id": ev_id
            }

        # Fallback default
        return None, None, {
            "phase": "VERIFICATION",
            "operation": "VERIFY_RECORD_ABSENT",
            "system_id": sys_id,
            "resource_id": res_id,
            "state": "ABSENT",
            "evidence_id": ev_id
        }
