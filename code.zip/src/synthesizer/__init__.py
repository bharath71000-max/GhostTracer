import sys
from pathlib import Path
REPO_ROOT = Path(__file__).resolve().parent.parent.parent
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

try:
    from .order_engine import StepOrderingEngine
    from .step_builder import StepBuilder
except (ImportError, ValueError):
    from src.synthesizer.order_engine import StepOrderingEngine
    from src.synthesizer.step_builder import StepBuilder

__all__ = ["StepOrderingEngine", "StepBuilder"]
