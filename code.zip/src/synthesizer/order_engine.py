"""
Deterministic Step Sorting and Sequencing Engine.
Guarantees 100% compliant multi-key ordering and 1-indexed numbering.
"""

import sys
from pathlib import Path

# Ensure repo root is on sys.path
REPO_ROOT = Path(__file__).resolve().parent.parent.parent
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from typing import List
from src.models.schemas import DeletionStep
from src.models.enums import AuditPhase

class StepOrderingEngine:
    PHASE_RANK = {
        AuditPhase.FINDING: 1,
        AuditPhase.REMEDIATION: 2,
        AuditPhase.VERIFICATION: 3,
        "FINDING": 1,
        "REMEDIATION": 2,
        "VERIFICATION": 3,
    }

    OPERATION_RANK = {
        # FINDINGS
        "REPORT_REMAINING_RECORD": 1,
        "REPORT_EXPOSED_PII": 2,
        "REPORT_ACTIVE_DATA_FLOW": 3,
        "REPORT_RESTORE_RISK": 4,
        # REMEDIATIONS
        "DISABLE_DATA_FLOW": 1,
        "BLOCK_RESTORE": 2,
        "DELETE_RECORD": 3,
        "REDACT_RECORD": 4,
        "ANONYMIZE_RECORD": 5,
        # VERIFICATIONS
        "VERIFY_RECORD_ABSENT": 1,
        "VERIFY_RECORD_PRESENT": 2,
        "VERIFY_RECORD_REDACTED": 3,
        "VERIFY_RECORD_ANONYMIZED": 4,
        "VERIFY_DATA_FLOW_DISABLED": 5,
        "VERIFY_RESTORE_BLOCKED": 6,
    }

    @classmethod
    def sort_and_renumber(cls, raw_steps: List[dict]) -> List[DeletionStep]:
        """
        Sorts step dicts by (phase_rank, op_rank, system_id, resource_id)
        and re-assigns sequential step_no starting at 1.
        """
        def sort_key(s: dict):
            p_val = s.get("phase")
            p_rank = cls.PHASE_RANK.get(p_val, 99)
            o_rank = cls.OPERATION_RANK.get(s.get("operation"), 99)
            sys_id = str(s.get("system_id", "")).lower()
            res_id = str(s.get("resource_id", "")).lower()
            return (p_rank, o_rank, sys_id, res_id)

        sorted_dicts = sorted(raw_steps, key=sort_key)

        final_steps: List[DeletionStep] = []
        for idx, s in enumerate(sorted_dicts, start=1):
            step_obj = DeletionStep(
                step_no=idx,
                phase=s["phase"],
                system_id=s["system_id"],
                resource_id=s["resource_id"],
                operation=s["operation"],
                state=s["state"],
                evidence_id=s.get("evidence_id", "")
            )
            final_steps.append(step_obj)

        return final_steps
