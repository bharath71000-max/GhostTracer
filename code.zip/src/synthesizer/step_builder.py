"""
Forensic Step Synthesizer and Case Decision Engine.
Constructs compliant steps_json arrays for COMPLETE, INCOMPLETE, and NOT_APPLICABLE cases.
"""

import sys
from pathlib import Path

# Ensure repo root is on sys.path
REPO_ROOT = Path(__file__).resolve().parent.parent.parent
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from typing import List, Dict, Tuple
from src.models.schemas import DeletionStep, AuditCaseResult, ObservedResource
from src.models.enums import DeletionStatus
from src.synthesizer.order_engine import StepOrderingEngine

class StepBuilder:
    def __init__(self):
        self.order_engine = StepOrderingEngine()

    def build_case_result(
        self,
        case_id: str,
        is_deletion_authorized: bool,
        evaluated_pairs: List[Tuple[dict, dict, dict]],
        primary_account_verification: dict = None
    ) -> AuditCaseResult:
        """
        Builds the final AuditCaseResult.
        evaluated_pairs is list of (finding_or_none, remediation_or_none, verification_dict).
        """
        # 1. Non-deletion request -> NOT_APPLICABLE
        if not is_deletion_authorized:
            return AuditCaseResult(
                case_id=case_id,
                deletion_status=DeletionStatus.NOT_APPLICABLE,
                steps_json=[]
            )

        findings: List[dict] = []
        remediations: List[dict] = []
        verifications: List[dict] = []

        for f, r, v in evaluated_pairs:
            if f is not None:
                findings.append(f)
            if r is not None:
                remediations.append(r)
            if v is not None:
                verifications.append(v)

        if primary_account_verification:
            verifications.append(primary_account_verification)

        # 2. Check completeness
        has_violations = len(findings) > 0

        if has_violations:
            status = DeletionStatus.INCOMPLETE
            # For INCOMPLETE cases, remediation & verification steps use evidence_id: ""
            remediations_clean = []
            for r in remediations:
                r_copy = dict(r)
                r_copy["evidence_id"] = ""
                remediations_clean.append(r_copy)

            verifications_clean = []
            for v in verifications:
                v_copy = dict(v)
                v_copy["evidence_id"] = ""
                verifications_clean.append(v_copy)

            raw_steps = findings + remediations_clean + verifications_clean
        else:
            status = DeletionStatus.COMPLETE
            # For COMPLETE cases, only verification steps are included, citing real evidence_id
            raw_steps = verifications

        # Deduplicate steps by (phase, system_id, resource_id, operation)
        seen_keys = set()
        deduped_raw_steps = []
        for s in raw_steps:
            k = (s["phase"], s["system_id"].lower(), s["resource_id"].lower(), s["operation"])
            if k not in seen_keys:
                seen_keys.add(k)
                deduped_raw_steps.append(s)

        sorted_steps = self.order_engine.sort_and_renumber(deduped_raw_steps)

        return AuditCaseResult(
            case_id=case_id,
            deletion_status=status,
            steps_json=sorted_steps
        )
