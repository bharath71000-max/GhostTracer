"""
Pydantic schemas and domain data models for the Ghost Data Forensic AI Auditor.
"""

import sys
from pathlib import Path

# Ensure repo root is on sys.path
REPO_ROOT = Path(__file__).resolve().parent.parent.parent
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from typing import List, Optional, Set
from pydantic import BaseModel, Field
from src.models.enums import DeletionStatus, AuditPhase, ResourceState

class DeletionStep(BaseModel):
    step_no: int = Field(ge=1, description="1-indexed sequence number of the step.")
    phase: AuditPhase = Field(description="FINDING, REMEDIATION, or VERIFICATION.")
    system_id: str = Field(description="Identifier of target system (e.g., account_service, search_service).")
    resource_id: str = Field(description="Identifier of target resource (e.g., account_005, search_052).")
    operation: str = Field(description="Operation code according to allowed operations.")
    state: str = Field(description="Resulting or observed resource state.")
    evidence_id: str = Field(default="", description="Participant-visible evidence ID (or empty string).")

class AuditCaseResult(BaseModel):
    case_id: str
    deletion_status: DeletionStatus
    steps_json: List[DeletionStep]

class IdentityGraph(BaseModel):
    stable_user_id: str
    primary_email: str
    all_emails: List[str]
    phone_numbers: List[str]
    email_hashes: List[str]
    full_names: List[str] = Field(default_factory=list)

    def contains_pii(self, text: str) -> bool:
        """Check if given text contains any resolved PII marker."""
        if not text:
            return False
        text_lower = text.lower()
        for email in self.all_emails:
            if email and email.lower() in text_lower:
                return True
        for phone in self.phone_numbers:
            if phone and len(phone) >= 7 and phone in text:
                return True
        for e_hash in self.email_hashes:
            if e_hash and len(e_hash) >= 16 and e_hash.lower() in text_lower:
                return True
        for name in self.full_names:
            if name and len(name) >= 4 and name.lower() in text_lower:
                return True
        return False

class ObservedResource(BaseModel):
    file_id: str
    captured_at: str
    system_id: str
    resource_id: str
    data_category: str
    state: str
    user_id: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    email_hash: Optional[str] = None
    full_name: Optional[str] = None
    has_pii: bool = False
    details: Optional[str] = None
