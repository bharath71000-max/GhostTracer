import os
os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"

from pathlib import Path

# Base directories
REPO_ROOT = Path(__file__).resolve().parent
DATASET_DIR = REPO_ROOT / "dataset"
EVIDENCE_DIR = DATASET_DIR / "evidence"
CODE_DIR = REPO_ROOT / "code"
EVALUATION_DIR = CODE_DIR / "evaluation"

# Primary CSV paths
DELETION_REQUESTS_PATH = DATASET_DIR / "deletion_requests.csv"
SAMPLE_REQUESTS_PATH = DATASET_DIR / "sample_deletion_requests.csv"
SAMPLE_OUTPUT_PATH = DATASET_DIR / "sample_output.csv"
USER_IDENTITIES_PATH = DATASET_DIR / "user_identities.csv"
USER_AUDIT_LOG_PATH = DATASET_DIR / "user_audit_log.csv"
DELETION_RULES_PATH = DATASET_DIR / "deletion_rules.csv"
SYSTEM_ACTIVITY_PATH = DATASET_DIR / "system_activity.csv"
EVIDENCE_FILES_PATH = DATASET_DIR / "evidence_files.csv"
OUTPUT_PATH = REPO_ROOT / "output.csv"

# Evaluation report paths
EVALUATION_REPORT_PATH = EVALUATION_DIR / "evaluation_report.md"
USAGE_REPORT_PATH = EVALUATION_DIR / "usage_report.md"
